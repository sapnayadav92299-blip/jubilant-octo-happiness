package dev.lelonio.square.playback

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/**
 * 16D and 18D: the music circling the listener's head, meant for headphones.
 *
 * Kept clear on purpose. The usual "8D" edit pans the whole mix and drowns it in
 * reverb, which is what makes it muddy. Here only the middle of the mix, above
 * the bass, goes round; the low end stays put in the centre, so the beat does
 * not wobble, and what is wide in the recording stays where it was. What goes
 * round is placed the way a real source would be:
 *  - a small gain difference between the ears (level),
 *  - a fraction of a millisecond of delay on the far ear (time),
 *  - the far ear a little duller, as a head would make it (shadow),
 *  - duller still while the sound is behind, then brighter in front.
 * No reverb is added.
 *
 * 18D goes round faster and wider than 16D, and its distance breathes slowly.
 */
object Spatial {
    const val OFF = 0
    const val D16 = 1
    const val D18 = 2

    internal class Shape(
        val periodSeconds: Double,
        val delayMs: Float,
        val shadow: Float,
        val breath: Float,
    )

    internal fun shape(mode: Int): Shape? = when (mode) {
        D16 -> Shape(periodSeconds = 6.0, delayMs = 0.60f, shadow = 0.55f, breath = 0f)
        D18 -> Shape(periodSeconds = 4.0, delayMs = 0.70f, shadow = 0.65f, breath = 0.12f)
        else -> null
    }
}

/**
 * [Spatial] over one stream of sixteen-bit stereo PCM.
 *
 * One per stream: it remembers where the sound is in its circle and the last
 * samples it filtered. Anything that is not stereo goes through untouched.
 */
class SpatialFilter {

    private var phase = 0.0
    private var breathPhase = 0.0

    /** 0 when off, 1 when fully on; moves over a third of a second so switching does not click. */
    private var amount = 0f

    private var low = 0f
    private var lpLeft = 0f
    private var lpRight = 0f
    private val history = FloatArray(HISTORY)
    private var write = 0

    /** In place, on [sizeInBytes] bytes of interleaved little-endian PCM. */
    fun apply(data: ByteBuffer, sizeInBytes: Int, channels: Int, sampleRate: Int) {
        if (channels != 2 || sampleRate <= 0) return
        val mode = AudioEffects.spatial.value
        val target = if (mode == Spatial.OFF) 0f else 1f
        if (target == 0f && amount <= 0f) {
            // Off and settled: start the circle from the front next time, where
            // it sounds exactly like the recording.
            phase = 0.0
            breathPhase = 0.0
            return
        }
        // Switching off fades out on the shape it was on; the rest of the time it is the mode's own.
        val shape = Spatial.shape(if (mode == Spatial.OFF) lastMode else mode) ?: return
        lastMode = if (mode == Spatial.OFF) lastMode else mode

        val shorts = data.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val samples = minOf(sizeInBytes / 2, shorts.limit())

        val fs = sampleRate.toFloat()
        val lowCoef = 1f - exp(-2f * PI.toFloat() * BASS_HZ / fs)
        val shadowCoef = 1f - exp(-2f * PI.toFloat() * SHADOW_HZ / fs)
        val turn = 2.0 * PI / (shape.periodSeconds * sampleRate)
        val breathTurn = 2.0 * PI / (BREATH_SECONDS * sampleRate)
        val maxDelay = shape.delayMs * 0.001f * fs
        val ramp = 1f / (0.33f * fs)

        var i = 0
        while (i + 2 <= samples) {
            amount = if (amount < target) min(target, amount + ramp) else max(target, amount - ramp)

            val l = shorts.get(i).toFloat()
            val r = shorts.get(i + 1).toFloat()
            val mid = (l + r) * 0.5f
            val side = (l - r) * 0.5f

            low += lowCoef * (mid - low)
            val high = mid - low

            history[write and MASK] = high

            val p = sin(phase).toFloat() * amount
            val front = cos(phase).toFloat()
            phase += turn
            if (phase >= 2.0 * PI) phase -= 2.0 * PI

            // Constant power, never all the way to one ear: the far ear keeps a
            // share, which is what keeps it from sounding like a hard pan.
            val angle = (p * PAN_DEPTH + 1f) * (PI.toFloat() / 4f)
            val gainL = cos(angle) * ROOT_TWO
            val gainR = sin(angle) * ROOT_TWO

            var breath = 1f
            if (shape.breath > 0f) {
                breath = 1f + shape.breath * amount * sin(breathPhase).toFloat()
                breathPhase += breathTurn
                if (breathPhase >= 2.0 * PI) breathPhase -= 2.0 * PI
            }

            // The far ear hears it later.
            val delayL = maxDelay * max(0f, p)
            val delayR = maxDelay * max(0f, -p)
            val heardL = read(delayL)
            val heardR = read(delayR)
            write++

            // Duller on the far ear, and duller still behind.
            val behind = max(0f, -front) * BEHIND_SHADOW * amount
            val dullL = min(0.9f, shape.shadow * max(0f, p) + behind)
            val dullR = min(0.9f, shape.shadow * max(0f, -p) + behind)
            lpLeft += shadowCoef * (heardL - lpLeft)
            lpRight += shadowCoef * (heardR - lpRight)
            val earL = heardL + (lpLeft - heardL) * dullL
            val earR = heardR + (lpRight - heardR) * dullR

            // Not rotated: the bass, and what is wide in the recording.
            // A little headroom while it is on: the near ear is louder than the
            // recording at the points of the circle, and a loud master would
            // otherwise clip there, which is the opposite of clear.
            val headroom = 1f - HEADROOM * amount
            val outL = (low + gainL * breath * earL + side * WIDTH) * headroom
            val outR = (low + gainR * breath * earR - side * WIDTH) * headroom

            shorts.put(i, clip(outL))
            shorts.put(i + 1, clip(outR))
            i += 2
        }
    }

    private var lastMode = Spatial.D16

    /** The middle signal as it was [delay] samples ago, between the two nearest. */
    private fun read(delay: Float): Float {
        val back = floor(delay).toInt()
        val frac = delay - back
        val a = history[(write - back) and MASK]
        val b = history[(write - back - 1) and MASK]
        return a + (b - a) * frac
    }

    /** Soft above [KNEE], so a peak is rounded off rather than flattened. */
    private fun clip(x: Float): Short {
        val a = abs(x)
        if (a <= KNEE) return x.toInt().toShort()
        val room = 32767f - KNEE
        val squeezed = KNEE + room * tanh((a - KNEE) / room)
        return (if (x < 0f) -squeezed else squeezed).toInt().toShort()
    }

    private companion object {
        const val HISTORY = 512
        const val MASK = HISTORY - 1
        /** Below this the sound stays in the centre. */
        const val BASS_HZ = 180f
        /** How dull the far ear gets. */
        const val SHADOW_HZ = 1800f
        const val BEHIND_SHADOW = 0.30f
        const val PAN_DEPTH = 0.85f
        const val WIDTH = 0.95f
        const val BREATH_SECONDS = 11.0
        const val ROOT_TWO = 1.4142135f
        const val HEADROOM = 0.15f
        const val KNEE = 24000f
    }
}
