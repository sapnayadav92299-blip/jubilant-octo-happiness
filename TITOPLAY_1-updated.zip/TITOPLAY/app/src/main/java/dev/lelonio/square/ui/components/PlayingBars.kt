package dev.lelonio.square.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Three bars rising and falling out of step: the mark of the row that is
 * playing.
 *
 * They move while the music does and settle to a low, even line when it is
 * paused, so a glance down a list says both which song it is and whether it is
 * going. Each runs at its own speed, which is what keeps them from reading as
 * one bar drawn three times.
 */
@Composable
fun PlayingBars(
    color: Color,
    playing: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 18.dp,
) {
    val transition = rememberInfiniteTransition(label = "playingBars")
    val first by transition.animateFloat(
        initialValue = 0.30f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse),
        label = "first",
    )
    val second by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(760, easing = LinearEasing), RepeatMode.Reverse),
        label = "second",
    )
    val third by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(640, easing = LinearEasing), RepeatMode.Reverse),
        label = "third",
    )
    // Eased in and out of rest, so pausing is a settling and not a freeze.
    val alive by animateFloatAsState(if (playing) 1f else 0f, tween(300), label = "alive")

    Canvas(modifier.size(size)) {
        val barWidth = this.size.width * 0.22f
        val gap = (this.size.width - barWidth * 3f) / 2f
        listOf(first, second, third).forEachIndexed { index, level ->
            val fraction = REST + (level - REST) * alive
            val height = this.size.height * fraction
            drawRoundRect(
                color = color,
                topLeft = Offset(index * (barWidth + gap), this.size.height - height),
                size = Size(barWidth, height),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}

/** How tall a bar is when nothing is playing, as a share of the whole. */
private const val REST = 0.30f
